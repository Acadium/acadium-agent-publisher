=== Acadium Agent Publisher ===
Contributors: anselbrandt
Tags: ai, mcp, claude, abilities, content
Requires at least: 6.9
Tested up to: 7.1
Requires PHP: 7.4
Stable tag: 1.1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Let Claude and other AI agents draft, review and publish posts, upload images and look up categories and tags, within rules you set.

== Description ==

Acadium Agent Publisher lets an AI agent, such as Claude, write and publish blog posts for your site through the WordPress Abilities API, and through the Model Context Protocol (MCP) when the MCP Adapter plugin is installed.

The agent signs in as its own WordPress user with an Application Password, and that user gets the **AI Agent** role that this plugin adds. Under **Settings > Agent Publisher** you decide how far the agent may go:

* **Drafts only** (default): the agent creates and edits its own drafts, and a person publishes them.
* **Submit for review**: the agent can also move its drafts to "Pending review" for an editor.
* **Publish**: the agent can also publish or schedule its own posts, after the checks you set, and unpublish them again.
* **Publish and edit live posts**: the agent can also change its own posts after they are live.

Checks before an agent publishes:

* a title and content are always required
* optional: a featured image with alt text
* optional: allowed categories
* optional: a daily limit

Every agent action is listed under Recent agent activity on the settings page.

= Safety =

* **The AI Agent role never has publishing rights.** It has only read, edit_posts, delete_posts and upload_files. Publishing, scheduling, unpublishing and editing live posts happen only through this plugin's abilities, which check your settings first. Even if the agent calls the regular REST API directly with its password, it cannot publish or change live content.
* **Agents only change their own posts.** They cannot touch other users' posts.
* **Unsafe HTML is removed.** WordPress strips scripts, iframes and event handlers from what the agent writes.
* **Uploads are checked.** The real file type must be JPEG, PNG, GIF or WebP, the size is limited, and URL uploads only fetch from public https addresses.

Publishing can trigger things that unpublishing cannot undo, such as subscriber emails or social media posts from other plugins. Start with "Drafts only".

= Abilities =

* `agent-publisher/get-capabilities` (read-only): what the site allows
* `agent-publisher/list-terms` (read-only)
* `agent-publisher/get-post` (read-only)
* `agent-publisher/create-draft-post`
* `agent-publisher/update-draft-post`
* `agent-publisher/upload-media`
* `agent-publisher/submit-for-review`
* `agent-publisher/publish-post` (publish now or schedule)
* `agent-publisher/unpublish-post`
* `agent-publisher/update-published-post`

They are available through the core Abilities REST API (`/wp-json/wp-abilities/v1/`; read-only abilities use GET, the others POST) and, with the MCP Adapter plugin, to MCP clients such as Claude Desktop and Claude Code.

= For developers =

Filters:

* `agent_publisher_post_types`: post types the post abilities work on (default: `post`).
* `agent_publisher_post_meta`: custom field keys agents may read and write (default: none).
* `agent_publisher_upload_mimes`: accepted image types (default: JPEG, PNG, GIF, WebP).
* `agent_publisher_max_upload`: maximum upload size in bytes (default: 10 MB).

Development happens on GitHub: https://github.com/Acadium/acadium-agent-publisher

== Installation ==

1. Install and activate Acadium Agent Publisher. This adds the **AI Agent** role.
2. For MCP clients (Claude Desktop, Claude Code), also install the MCP Adapter plugin from https://github.com/WordPress/mcp-adapter/releases.
3. Go to Users > Add New User and create a user for the agent (for example `claude`) with the role **AI Agent**. Do not give the agent the Author, Editor or Administrator role.
4. Edit that user and create an Application Password under "Application Passwords". Copy it; it is shown once.
5. Choose what the agent may do under Settings > Agent Publisher (default: Drafts only).
6. Connect your AI client to `https://your-site/wp-json/mcp/mcp-adapter-default-server` with the agent's username and Application Password. The GitHub README has ready-to-paste configurations for Claude Desktop and Claude Code.

Your site must use HTTPS (WordPress disables Application Passwords on plain HTTP).

== Frequently Asked Questions ==

= Can the agent publish posts? =

Only if you choose "Publish" or "Publish and edit live posts" under Settings > Agent Publisher. By default it can only create drafts, and a person publishes them.

= Can the agent bypass these settings through the REST API? =

No. The AI Agent role has no publishing capabilities, so the regular REST API refuses to publish or edit live posts for it in every mode. Only this plugin's abilities can do that, after checking your settings.

= Does this plugin connect to external services? =

No. It does not contact any server on its own. The upload ability downloads an image only when the agent supplies an image URL, and only from public https addresses.

= Do scheduled posts need anything special? =

They are published by WordPress' scheduler (WP-Cron), like posts you schedule yourself. If your site disables WP-Cron, make sure a server cron job runs it.

= How do I revoke access? =

Revoke the agent's Application Password under Users > (agent) > Application Passwords, or delete the agent user. Deactivating the plugin removes the abilities.

= The agent gets a 401 error although the password is correct =

Your web server may be removing the Authorization header, which is common with Apache and CGI/FastCGI. Add `SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1` to your .htaccess, and make sure security plugins allow Application Passwords and REST API access for logged-in users.

== Changelog ==

= 1.1.0 =
* Publishing modes under Settings > Agent Publisher: drafts only (default), submit for review, publish, publish and edit live posts.
* New abilities: get-capabilities, submit-for-review, publish-post (now or scheduled), unpublish-post, update-published-post.
* Pre-publish checks: featured image with alt text, allowed categories, daily limit.
* Recent agent activity on the settings page.
* The AI Agent role (previously "AI Agent (drafts only)") never has publishing capabilities; publishing goes only through the plugin's abilities.
* Write abilities now all use POST in the core Abilities REST API (update-draft-post previously required DELETE).

= 1.0.0 =
* First release: list terms, get post, create draft post, update draft post and upload media abilities, plus the AI Agent (drafts only) role.

== Upgrade Notice ==

= 1.1.0 =
Adds optional publishing. The default stays "Drafts only"; nothing changes until you pick another mode under Settings > Agent Publisher.
